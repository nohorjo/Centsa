java -cp lib:. -jar lib/Centsa*.jar
