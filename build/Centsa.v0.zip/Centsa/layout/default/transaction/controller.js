app.controller("transCtrl", function($scope) {
	$scope.transactions = [];
});