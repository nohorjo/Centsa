Windows:
	Run install-run.bat

Linux:
	Run install-run.sh

Refer to https://github.com/nohorjo/Centsa for guides, changelog and license information.
